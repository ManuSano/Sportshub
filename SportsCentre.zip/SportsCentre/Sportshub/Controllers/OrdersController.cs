﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sportshub.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Sportshub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IConfiguration _configuration;


        public OrdersController(IConfiguration configuration)
        {

            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult DetailsofOrder()
        {
            string query = " select * from Orders";

            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult(table);


        }

        [HttpPost]
        public JsonResult InsertinginOrders(Orders Ord)
        {
            string query = @" insert into Orders(ContactNumber,Order_Address,Order_Deliverdate,PaymentMode,Cust_ID,ItemNumber)
                 values
                 (' " + Ord.ContactNumber    + @" ',
                 ' " +  Ord.Order_Address     + @" ',
                 ' " +  Ord.Order_Deliverdate + @" ',
                 ' " +  Ord.PaymentMode       + @" ',
                 ' " +  Ord.Cust_Id           + @" ',
                 ' " +  Ord.ItemNumber        + @" '
                 )";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Added Succesfully");

        }


        [HttpPut]
        public JsonResult UpdatingOrders(Orders Ord)
        {
            string query = @" update Orders set
                  ContactNumber        = ' " + Ord.ContactNumber      + @" ',
                  Order_Address        = ' " + Ord.Order_Address      + @" ',
                  Order_Deliverdate        = ' " + Ord.Order_Deliverdate  + @" ',
                  PaymentMode          = ' " + Ord.PaymentMode        + @" ',
                  Cust_Id              = ' " + Ord.Cust_Id            + @" ',
                  ItemNumber           = ' " + Ord.ItemNumber         + @" '
                  Where Order_ID        = ' " + Ord.Order_ID  + @" '
                 ";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Updated Succesfully");

        }

        [HttpDelete("{id}")]
        public JsonResult DeletingOrders(int id)
        {

                string query = @" Delete from Orders 
                               where Order_ID =" + id + @" 
                             ";


                DataTable table = new DataTable();
                string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
                SqlDataReader myReader;
                using (SqlConnection myCon = new SqlConnection(SqlDataSource))
                {
                    myCon.Open();
                    using (SqlCommand myCommand = new SqlCommand(query, myCon))
                    {
                        myReader = myCommand.ExecuteReader();
                        table.Load(myReader);


                        myReader.Close();
                        myCon.Close();
                    }
                }


                return new JsonResult("Deleted Succesfully");
            }
           
        }
}

    


﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sportshub.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Sportshub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly IConfiguration _configuration;


        public CustomersController(IConfiguration configuration)
        {

            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult DetailsOfCustomer()
        {
            string query = " select * from Customer";

            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult(table);


        }

        [HttpPost]
        public JsonResult InsertinginCustomer(Customer Cust)
        {
            string query = @" insert into Customer(Cust_Name,ContactNumber,Address,Email)
                 values
                 (' " + Cust.Cust_Name + @" ',
                 ' " + Cust.ContactNumber + @" ',
                 ' " + Cust.Address + @" ',
                 ' " + Cust.Email + @" '
                 )";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Added Succesfully");

        }


        [HttpPut]
        public JsonResult UpdateinCustomers(Customer Cust)
        {
            string query = @" update Customer set
                  Cust_Name     = ' " + Cust.Cust_Name + @" ',
                  ContactNumber = ' " + Cust.ContactNumber + @" ',
                  Address       = ' " + Cust.Address + @" ',
                  Email         = ' " + Cust.Email + @" '
                  Where Cust_Id = ' " + Cust.Cust_Id + @" '
                 ";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Updated Succesfully");

        }

        [HttpDelete("{id}")]
        public JsonResult DeleteinCustomer(int id)
        {
            string query = @" Delete from Customer 
                               where Cust_Id =" + id + @" 
                             ";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Deleted Succesfully");

        }
    }


}
   

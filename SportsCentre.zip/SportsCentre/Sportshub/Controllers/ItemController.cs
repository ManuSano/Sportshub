﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Sportshub.Models;
using Microsoft.IdentityModel.Protocols;

namespace Sportshub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IConfiguration _configuration;


        public ItemController(IConfiguration configuration)
        {

            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult ItemDetails()
        {
            string query = " select * from Item ";

            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult(table);


        }

        [HttpPost]
        public JsonResult InsertinginItems(Item item)
        {
            string query = @" insert into Item(ItemName,ItemValue,Color,Size)
                 values
                 (' " + item.itemName + @" ',
                 ' " + item.itemValue + @" ',
                 ' " + item.Color + @" ',
                 ' " + item.Size + @" '
                 )";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Added Succesfully");

        }


        [HttpPut]
        public JsonResult UpdatinginItems(Item item)
        {
            string query = @" update Item set
                  ItemName   = ' " + item.itemName + @" ',
                  ItemValue = ' " + item.itemValue + @" ',
                  Color     = ' " + item.Color + @" ',
                  Size      = ' " + item.Size + @" '
                  Where ItemNumber =' " + item.itemNumber + @" '
                 ";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Updated Succesfully");

        }

        [HttpDelete("{id}")]
        public JsonResult DeletinginItem(int id)
        {
            string query = @" Delete from Item 
                           where ItemNumber =" + id + @" 
                             ";


            DataTable table = new DataTable();
            string SqlDataSource = _configuration.GetConnectionString("SportshubCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(SqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Deleted Succesfully");

        }
    }


    }


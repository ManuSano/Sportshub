﻿using Microsoft.EntityFrameworkCore;
using ServiceStack.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Sportshub.Models
{
    
    public class Item
    {
        [Key]
        public int itemNumber { get; set; }
        public string itemName { get; set; }
        public string itemValue { get; set; }
        public string Color { get; set; }
        public string Size { get; set; }
    }
}

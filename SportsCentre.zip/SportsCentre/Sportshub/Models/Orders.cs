﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Sportshub.Models
{
    
    public class Orders
    {
        [Key]
        public int Order_ID { get; set; }
        public int ContactNumber { get; set; }
        public string Order_Address { get; set; }
        public string Order_Deliverdate { get; set; }
        public string PaymentMode { get; set; }
        public int Cust_Id { get; set; }

        [ForeignKey("Cust_Id")]
        public Customer Customers { get; set; }
        public int ItemNumber { get; set; }

        [ForeignKey("ItemNumber")]
        public Item Items { get; set; }

    }
}
